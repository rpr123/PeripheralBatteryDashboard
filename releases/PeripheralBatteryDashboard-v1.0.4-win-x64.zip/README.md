# Peripheral Battery Dashboard

Windows에서 동글 또는 Bluetooth로 연결한 주변기기의 배터리 상태를 한 화면과 트레이에서 확인하는 앱입니다. 장치 식별 정보는 JSON 프로필에, 실제 조회 프로토콜은 공급자(provider)에 분리되어 있어 기기를 교체하거나 추가하기 쉽습니다.

> [!IMPORTANT]
> **이 프로젝트의 공식 설치 방식은 로컬 Windows에 접근할 수 있는 Codex 또는 코딩 에이전트를 통하는 것입니다. 사용자가 ZIP을 직접 내려받아 실행하거나 소스를 직접 빌드·배치하는 설치 절차는 제공하지 않습니다.**
> 아래 프롬프트를 코드 블록의 처음부터 끝까지 복사해 Codex Desktop 같은 로컬 코딩 에이전트에 전달하세요. 일반 웹 채팅처럼 로컬 파일·셸·장치에 접근할 수 없는 환경에서는 설치와 호환성 진단을 끝낼 수 없습니다.

## 공식 설치 요청 방법

설치·업데이트와 새로운 장치 지원 조정은 Codex 같은 로컬 코딩 에이전트가 저장소 문서·진단 결과·소스를 함께 검토하며 수행하는 것을 전제로 합니다. 설치가 완료된 뒤 배터리 대시보드와 트레이 기능을 평소에 사용하는 데에는 Codex가 필요하지 않습니다.

1. 설치할 Windows PC에서 로컬 셸과 파일을 사용할 수 있는 Codex 또는 코딩 에이전트를 엽니다. 저장소와 ZIP을 사용자가 먼저 받을 필요는 없습니다.
2. 아래 프롬프트 **전체**를 그대로 전달하고, 마지막의 기기 정보만 채웁니다.
3. 에이전트가 공식 저장소 확보, 배포본 다운로드 또는 소스 빌드, 안정된 설치 위치 배치, 자체 테스트와 호환성 확인을 순서대로 수행하게 합니다.
4. 에이전트가 다운로드·설치·레지스트리/자동 실행 변경·첫 GUI 실행 또는 실제 장치 요청 전에 설명하는 대상과 영향을 확인하고 승인 여부를 결정합니다.

```text
Peripheral Battery Dashboard의 공식 에이전트 설치 흐름에 따라 내 Windows PC에 앱을 안전하게 설치하고, 연결된 주변기기와의 호환성을 점검해 줘. 내가 저장소를 직접 복제하거나 ZIP을 내려받아 압축 해제하고, 소스를 빌드하거나 설치 파일을 배치하도록 넘기지 말고 네가 승인 경계를 지키며 전체 설치를 수행해라.

대상 저장소: https://github.com/rpr123/PeripheralBatteryDashboard

진행 순서:
1. 먼저 읽기 전용으로 Windows 10/11 x64 여부, .NET Framework 4.8, Git과 VS 2022 Build Tools 유무, 기존 설치 위치와 후보 설치 경로를 확인하고 계획을 요약한다. 앱 실행과 현재 사용자용 Release 설치에는 관리자 권한이 필요하지 않다. 누락된 Microsoft 런타임이나 빌드 도구가 권한 상승을 요구하면 별도 승인 없이 설치하지 말고 Release 경로 또는 `설치 보류(blocked)`를 선택한다.
2. 기존 프로젝트 폴더가 있으면 origin URL이 위 공식 URL과 같은지, HEAD와 dirty 상태를 읽기 전용으로 확인하고 사용자 변경을 보존한다. origin이 다르면 그 복사본을 실행하지 않는다. 공식 로컬 복사본이 없으면 공식 Release ZIP과 SHA 파일을 받을지, 위 URL을 `git clone`할지 판단하고 정확한 URL·대상 경로·생길 파일을 보여 준 뒤 네트워크와 쓰기에 대한 승인을 기다린다.
3. clone을 선택하면 origin과 HEAD를 확인한 뒤 저장소 문서를 읽는다. Release를 선택하면 공식 ZIP과 `SHA256SUMS.txt`를 받고, 압축 해제나 실행 전에 SHA-256을 정확히 비교한다. 불일치하면 즉시 중단한다. 일치하면 압축을 해제한 뒤 포함된 README.md, AGENTS.md, CODEX-PROMPTS.md, DEVICE-ADDING.md를 읽는다. SmartScreen이나 보안 경고를 임의로 우회하지 않는다.
4. 검증된 배포본과 소스 빌드 중 적합한 방법을 선택한다. 빌드한다면 격리된 출력 폴더를 사용한다. 다운로드, 빌드 도구·런타임 설치, 저장소 밖의 안정된 앱 폴더 쓰기 등 외부 상태 변경 전에 정확한 대상과 영향을 설명하고 내 승인을 받는다.
5. 설치 후 실제 장치 I/O가 없는 `PeripheralBatteryDashboard.Diagnostics.exe --self-test`를 먼저 실행하고 종료 코드를 확인한다.
6. GUI 첫 실행 전에 자동 실행을 켤지 끌지 묻는다. 끄기를 선택하면 전체 설정 파일과 `StartWithWindows=false` 쓰기를 설명하고 승인 후 먼저 준비한다. 켜기를 선택하면 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run\PeripheralBatteryDashboard` 값과 정확한 실행 명령을 보여 준다. GUI는 이 레지스트리 상태를 동기화하고 모니터를 시작해 exact-match 기존 공급자의 장치 요청을 보낼 수 있음을 함께 설명한 뒤 첫 실행에 대한 별도 승인을 기다린다. 승인이 없으면 GUI 실행과 관련 파일·레지스트리 변경을 보류한다.
7. `--diagnostics`와 `--snapshot`은 매칭된 기존 ProviderId의 검증된 배터리 요청을 실제 장치에 보낼 수 있다. 실행 전에 대상 ProviderId, 장치 매칭과 수행될 I/O를 설명하고 내 명시적 확인을 기다린다. 장치 시리얼, 전체 장치 경로, Bluetooth 주소, 사용자명, 토큰은 출력·업로드·커밋하지 않는다.
8. 내 기기가 현재 지원되지 않으면 값을 추정하지 말고 JSON 프로필만 필요한지 새 공급자 플러그인이 필요한지 근거와 함께 분류한다. 알 수 없는 HID interrupt/output/Feature write, 무작위 바이트, 명령 공간 스캔·퍼징, 펌웨어·페어링·DPI·키맵·온보드 설정 변경은 절대 사용하지 않는다. 근거 없는 새 프로토콜은 `지원 보류(blocked)`로 보고하고, 검증된 새 요청도 정확한 대상·전송 바이트·읽기 전용 근거를 보여 준 뒤 별도 승인을 받는다.
9. 최종 보고에는 공식 소스 획득 방법과 origin/commit 또는 Release SHA-256, 설치 위치, 관리자 권한 사용 여부, 변경 파일, 빌드와 --self-test 종료 코드, 자동 실행 선택·승인과 실제 파일/레지스트리 상태, 실기기 I/O 여부와 ProviderId, 새 HID write 전송 여부, 실제 확인한 기기와 남은 제약을 포함한다. 내 요청 없이 GitHub 게시, 커밋, 푸시 또는 릴리스를 하지 않는다.

내 기기 정보:
- 제품명: (여기에 입력)
- 연결 방식: (Bluetooth / 2.4GHz USB 동글 / 유선)
- 현재 증상: (표시 안 됨 / 배터리 값이 틀림 / 설치 필요 등)
```

설치·업데이트·진단·미지원 기기 추가를 따로 요청하려면 사용자가 명령을 직접 실행하지 말고 [CODEX-PROMPTS.md](CODEX-PROMPTS.md)의 목적별 프롬프트를 로컬 에이전트에 전달하세요. 경량급 Codex 모델(예: Luna)은 문서에 정해진 설치·빌드·기존 공급자용 프로필 추가에 적합합니다. 알려지지 않은 동글 프로토콜을 근거 자료에서 분석하고 새 공급자를 구현하는 작업은 더 강한 추론 모델을 권장하며, 어떤 모델도 근거 없는 HID 명령을 시험해서는 안 됩니다.

## 화면 예시

대시보드에서는 연결된 장치의 배터리 잔량과 연결 방식, 마지막 업데이트 시각을 한 화면에서 확인할 수 있습니다. 아래 배터리 수치는 촬영 당시의 예시입니다.

![헤드셋, 키보드, 마우스와 Xbox 컨트롤러의 배터리를 보여 주는 Peripheral Battery Dashboard](docs/images/dashboard-overview.png)

기기별 트레이 표시를 선택하면 작업표시줄 우하단에서 헤드셋·키보드·마우스·게임패드 실루엣과 배터리 숫자를 각각 확인할 수 있습니다.

![기기별 배터리 숫자가 표시된 Windows 트레이 아이콘](docs/images/tray-device-icons.png)

## 에이전트용 배포 정보

아래 자산은 설치 에이전트가 공식 배포본을 선택할 때 사용하는 입력입니다. 사용자가 직접 내려받아 압축을 풀고 실행하는 설치 흐름은 이 프로젝트의 지원 대상이 아닙니다.

- Windows x64 배포본: [PeripheralBatteryDashboard-v1.0.4-win-x64.zip](releases/PeripheralBatteryDashboard-v1.0.4-win-x64.zip)
- SHA-256 목록: [releases/SHA256SUMS.txt](releases/SHA256SUMS.txt)

에이전트는 다운로드 후 다음 명령으로 해시를 계산하고 `SHA256SUMS.txt`의 값과 비교해야 합니다. 값이 다르면 압축 해제나 실행을 중단하고 사용자에게 보고합니다.

```powershell
Get-FileHash .\PeripheralBatteryDashboard-v1.0.4-win-x64.zip -Algorithm SHA256
```

현재 배포 바이너리는 Authenticode 코드 서명이 되어 있지 않습니다. 따라서 Windows SmartScreen 또는 백신이 **알 수 없는 게시자** 경고를 표시할 수 있습니다. 에이전트는 경고를 자동으로 우회해서는 안 되며, 공식 출처와 SHA-256 확인 결과를 사용자에게 보여 주고 실행 여부를 별도로 승인받아야 합니다. 필요하면 에이전트가 저장소 소스를 검토하고 아래 빌드 참고에 따라 직접 생성할 수 있습니다.

요구 환경은 **Windows 10/11 x64와 .NET Framework 4.8**입니다. 기본 프로필은 아래 표의 정확한 기기 및 현재 확인된 하드웨어 매칭만 지원합니다. 같은 제품군, 다른 리비전 또는 다른 VID/PID가 자동으로 호환된다는 뜻이 아닙니다.

## 기본 지원 장치

| 장치 | 연결 | 표시 방식 |
|---|---|---|
| SteelSeries Arctis Nova 7 Gen 2 | 2.4GHz USB 동글 | 잔량 백분율, 충전 상태 |
| AULA F108 Pro | 2.4GHz USB 동글 | 잔량 백분율 |
| VXE R1 SE+ | 2.4GHz USB 동글 | 잔량 백분율, 충전 상태, 전압 |
| Xbox Wireless Controller | Bluetooth/XInput | Bluetooth GATT 백분율, 가능하면 XInput 4단계 잔량 |

현재 USB 동글 기본 매칭은 Arctis Nova 7 Gen 2 `1038:227E`(MI 03, Usage `FFC0:0001`), AULA F108 Pro `05AC:024F`(MI 03, Usage `FF60:0061`), VXE R1 SE+ `373B:1085`(MI 01, Usage `FF02:0002`)입니다. Xbox 기본 프로필은 `045E:0B13`과 Bluetooth/XInput 경로를 사용합니다. 실제 기준은 [Profiles/builtin.devices.json](Profiles/builtin.devices.json)이며, PID나 HID 컬렉션이 다르면 같은 제품명이어도 별도 확인이 필요합니다.

Xbox 컨트롤러는 연결 여부를 XInput 입력 상태로 확인합니다. Bluetooth 연결에서 XInput 배터리 정보가 비어 있으면 표준 Bluetooth Battery Service(GATT)를 읽어 백분율로 표시합니다. XInput이 건전지 잔량을 제공하는 연결 방식에서는 `교체 필요 / 부족 / 보통 / 충분` 4단계로 표시하며, 두 배터리 API 모두 값을 주지 않더라도 연결된 패드를 미연결로 오판하지 않습니다.

## 에이전트 설치 후 사용

에이전트는 설치가 끝나면 안정된 설치 위치, 자체 테스트 결과, 자동 실행 상태와 실행 방법을 최종 보고해야 합니다. 설치 후 평소 사용에는 에이전트가 필요하지 않습니다.

1. 전원이 꺼지거나 절전 중인 장치는 버튼을 누르거나 움직여 깨운 뒤 앱에서 **새로고침**을 누릅니다.
2. 창을 닫으면 기본 설정에서는 트레이로 최소화됩니다. 완전히 종료하려면 트레이 메뉴의 **종료**를 사용합니다.
3. 트레이에 숨겨진 상태에서 에이전트가 안내한 앱 바로가기 또는 실행 파일을 열면 기존 창이 앞으로 나타납니다. 중복 모니터 프로세스는 만들지 않습니다.

기본 설정에서는 현재 Windows 사용자가 로그인할 때 앱이 창 없이 트레이에서 자동 실행됩니다. 자동 실행됐다는 별도 알림은 표시하지 않으며, 실제 배터리 부족 알림만 기존 설정에 따라 표시합니다. GUI의 **Windows 로그인 시 자동 실행** 체크박스로 언제든 켜거나 끌 수 있고 관리자 권한은 필요하지 않습니다.

설치 후 앱 폴더를 사용자가 직접 옮기거나 일부 파일만 삭제하지 마세요. 위치 변경이나 업데이트가 필요하면 이 저장소 URL과 [CODEX-PROMPTS.md](CODEX-PROMPTS.md)의 설치 프롬프트를 다시 에이전트에 전달해 자동 실행 경로와 파일 구성을 함께 조정하게 하세요.

트레이 표시의 기본값은 **기기별 아이콘**입니다. 헤드셋·키보드·마우스·게임패드는 각각 다른 기기 실루엣으로 구분하고, 실루엣 안에 배터리 숫자와 충전·저전력 색상을 표시합니다. 마우스를 올리면 장치 이름·정확한 퍼센트·충전 또는 연결 상태를 확인할 수 있고, 왼쪽 클릭하면 대시보드가 열립니다. 설정에서 **통합 아이콘**으로 즉시 전환하면 특정 장치로 오해하지 않도록 별도의 공용 모양을 사용합니다. 이 표시는 기존 조회 결과를 재사용하므로 USB/Bluetooth 조회 횟수는 늘어나지 않습니다.

Windows 11은 새 트레이 아이콘을 숨겨진 아이콘 영역으로 접을 수 있습니다. 앱에서는 아이콘을 강제로 항상 표시할 수 없으므로, 필요한 경우 Windows의 **설정 → 개인 설정 → 작업 표시줄 → 기타 시스템 트레이 아이콘**에서 각 아이콘을 켜세요. 앱 폴더 경로가 바뀌면 Windows가 새 아이콘으로 인식할 수 있어 업데이트 후 이 설정을 다시 켜야 할 수도 있습니다.

요구 환경은 Windows 10/11 x64와 .NET Framework 4.8입니다. 제조사 프로그램이 같은 HID 인터페이스를 독점하고 있으면 `다른 앱이 장치 사용 중`으로 표시될 수 있습니다.

## 조회 주기와 시스템 부담

기본 조회 주기는 30초이며 설정에서 15, 30, 60, 120초를 선택할 수 있습니다. 한 번의 조회는 작은 HID/XInput 상태 요청뿐이고 동시에 두 장치까지만 처리하므로 15초도 일반적인 PC에서 부담이 매우 작습니다. 연결이 끊겼거나 응답하지 않는 장치는 실패가 반복될수록 조회 간격을 자동으로 늘리며 최대 5분까지 쉬었다가 재시도합니다.

Xbox Bluetooth 잔량은 첫 연결과 최대 5분마다만 패드에 직접 확인하고, 그 사이에는 Windows Bluetooth 캐시를 읽습니다. 따라서 앱의 15초 화면 갱신이 15초마다 컨트롤러를 깨우지는 않습니다.

배터리 절약을 우선하면 30초 또는 60초를 권장합니다. 15초 주기는 화면을 자주 확인하거나 충전 상태 변화를 빠르게 보고 싶을 때 사용하면 됩니다.

## 에이전트용 진단 도구

문제가 생기면 사용자가 명령을 직접 실행하기보다 [CODEX-PROMPTS.md](CODEX-PROMPTS.md)의 **변경 없이 진단만** 프롬프트를 에이전트에 전달하세요. 에이전트는 다음 명령의 I/O 차이와 매칭된 장치를 설명하고, 실기기 요청이 가능한 명령은 사용자의 명시적 확인을 받은 범위에서만 실행해야 합니다.

```powershell
.\PeripheralBatteryDashboard.Diagnostics.exe --snapshot
.\PeripheralBatteryDashboard.Diagnostics.exe --diagnostics
.\PeripheralBatteryDashboard.Diagnostics.exe --self-test
```

- `--snapshot`: 현재 배터리 판독값을 JSON으로 출력합니다. 매칭된 기존 공급자의 검증된 상태 요청을 실제 장치에 보낼 수 있습니다.
- `--diagnostics`: 배터리 상태, 적용 프로필, HID 컬렉션 정보를 텍스트로 출력합니다. 매칭된 기존 공급자의 검증된 상태 요청을 실제 장치에 보낼 수 있으며, 출력에서 장치 경로와 시리얼은 제외됩니다.
- `--self-test`: 프로필 형식, 체크섬, 공급자 등록 같은 앱 자체 구성을 검사합니다. 장치 연결 여부와 무관하고 실제 장치 요청 없이 실행할 수 있습니다.

GUI의 장치 관리 화면에서도 진단 정보를 파일로 내보낼 수 있습니다. 문의할 때는 이 파일을 사용하고, 장치 경로나 시리얼을 별도로 공유하지 마세요.

## 설정과 사용자 데이터

사용자 설정과 가져온 프로필은 다음 위치에 저장됩니다.

```text
%LOCALAPPDATA%\PeripheralBatteryDashboard\settings.json
%LOCALAPPDATA%\PeripheralBatteryDashboard\Profiles\devices.user.json
```

자동 실행은 현재 사용자의 `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`에 등록됩니다. 설치 위치 변경이나 업데이트는 에이전트가 이 등록값과 앱 폴더를 함께 확인하며 수행하게 하세요.

앱 폴더의 `Profiles\builtin.devices.json`은 기본 프로필입니다. 업데이트 시 덮어쓸 수 있으므로 직접 편집하지 말고, 에이전트가 생성·검증한 개인 프로필만 GUI의 **프로필 가져오기** 또는 위 사용자 프로필 폴더로 적용하게 하세요. 프로필과 플러그인은 시작할 때 읽으므로 변경 후 앱을 완전히 종료했다가 다시 실행해야 합니다.

장치 교체와 추가에는 [CODEX-PROMPTS.md](CODEX-PROMPTS.md)의 목적별 프롬프트를 사용하세요. [DEVICE-ADDING.md](DEVICE-ADDING.md)는 사용자가 따라 하는 설치 절차가 아니라 에이전트가 읽는 구현 참고 문서입니다.

## 에이전트용 소스 빌드 참고

이 절차는 배포본 대신 소스 빌드가 필요하다고 판단한 에이전트를 위한 참고입니다. 사용자에게 명령 실행을 넘기는 수동 설치 절차가 아닙니다.

필요 항목:

- Visual Studio 2022 Build Tools의 **Desktop development with .NET** 구성 요소
- .NET Framework 4.8 Runtime 또는 Developer Pack
- Windows PowerShell 5.1 이상

에이전트는 프로젝트 폴더에서 다음을 실행합니다.

```powershell
PowerShell -NoProfile -File .\build.ps1
```

디버그 심볼과 최적화 해제 빌드가 필요하면 다음을 사용합니다.

```powershell
PowerShell -NoProfile -File .\build.ps1 -Configuration Debug
```

스크립트는 VS 2022 Roslyn 컴파일러와 .NET Framework 참조 어셈블리를 자동으로 찾습니다. 먼저 `PeripheralBatteryDashboard.Runtime.dll`을 만든 다음 GUI와 Diagnostics 실행 파일이 그 공용 DLL을 함께 참조하게 합니다. 이 구조 덕분에 외부 플러그인의 `IBatteryProvider` 타입이 두 실행 파일에서 동일하게 유지됩니다.

## 문제 발생 시

설치·업데이트·호환성 문제는 직접 드라이버나 설치 파일을 바꾸기보다 [CODEX-PROMPTS.md](CODEX-PROMPTS.md)의 진단 프롬프트를 에이전트에 전달하세요. 아래 항목은 에이전트가 우선 점검할 일반적인 원인입니다.

- **동글 연결 안 됨:** 동글을 다시 꽂고 장치의 전원을 켠 뒤 새로고침합니다. USB 허브 대신 본체 포트도 시험해 보세요.
- **절전 또는 응답 없음:** 키보드 키를 누르거나 마우스를 움직인 뒤 다시 조회합니다.
- **다른 앱이 장치 사용 중:** SteelSeries GG, 키보드/마우스 설정 도구 등 제조사 앱을 잠시 닫습니다.
- **Xbox 연결 안 됨:** 컨트롤러 전원을 켜고 Windows Bluetooth 페어링을 확인합니다. Steam Input이나 게임에서 먼저 잡은 슬롯도 XInput에서 검색됩니다.
- **지원 모듈 또는 플러그인 오류:** 진단 프롬프트를 에이전트에 전달해 `ProviderId`, Runtime DLL 참조와 파일 차단 상태를 점검하게 합니다. 신뢰할 수 없는 DLL을 직접 설치하거나 차단 해제하지 마세요.

## 라이선스

앱 소스와 저장소 문서는 [MIT License](LICENSE)로 배포됩니다. 프로토콜 조사에 참고한 외부 자료와 별도 저작권 고지는 [THIRD-PARTY-NOTICES.md](THIRD-PARTY-NOTICES.md)를 확인하세요.
